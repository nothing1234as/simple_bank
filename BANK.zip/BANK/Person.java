

public abstract class Person{
     
    String nationalCode;
    String name;
    String birthDate;
    String password;


    

    public abstract void logIn();
    public abstract String Nation();
}
        


    

