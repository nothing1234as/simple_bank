import java.util.ArrayList;
import java.util.Scanner;

class Customer extends Person {
    

    private ArrayList<Account> accounts = new ArrayList<>();
    static final int accCount = 3;
    

    public Customer(String nationalCode, String name, String birthDate , String password) {
        this.nationalCode = nationalCode;
        this.name = name;
        this.birthDate = birthDate;
        this.password = password;
    }

    public Customer() {
    }
    
    @Override
    public String Nation(){
        return this.nationalCode;
    }

    public void transfer(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("enter origin account ID: ");
        int originID = scanner.nextInt();
        for(Account account1 : accounts){
            if (originID == account1.getID()){
                System.out.println("origin account was found.");
                System.out.println("enter aim account ID: ");
                int aimID = scanner.nextInt();

                int find1 = 0;
                for(Account account2 :accounts){
                if(aimID == account2.getID()){
                   System.out.println("aim account was found.");
                   find1 = 1;
                   System.out.println("how much do you want to transfer: ");
                   int money1 = scanner.nextInt();
                   if(account1.withdraw(money1) == true){
                      account2.deposit(money1);
                      System.out.println("operation done!");
                      break; 
                   }
                }

                   }
                if(find1 == 0){
                    for(Customer customer : Bank.clients){
                        for(Account account3 : customer.getAccounts()){
                            if(account3.getID() == aimID){
                                System.out.println("aim account was found.");
                                
                                if(Cashier.permission() == 1){
                                   System.out.println("transfer was accepted.");
                                   System.out.println("how much do you want to transfer: ");
                                   int money2 = scanner.nextInt();
                                   if(account1.withdraw(money2) == true){
                                    account3.deposit(money2);
                                    System.out.println("operation done!");
                                    break; 
                                 }
                                }
                                else{
                                    System.out.println("transfer was denied.");
                                    break;
                                }
                            }
                        }
                    }
                }
               
            }
        }
       
        
    
    }
    
    
    @Override
    public void logIn(){
        Scanner scanner = new Scanner(System.in);
         System.out.println("enter your password");
         String pass = scanner.nextLine();
        if(this.password.equals(pass)){
            System.out.println("welcome back Sir!");
            menu();
        }
        else{
            System.out.println("password was not correct!");
        }

    }

    public int getAccountBalance(){
        int cusTotal = 0;
        for(Account account : accounts){
            cusTotal = cusTotal + account.getBalance();
        }
        return cusTotal;
    }

    public ArrayList<Account> getAccounts(){
        return accounts;
    }
    public String showInfo(){
        return "costumer: {natioanl code: "+nationalCode+"| name: "+name+"| birth date: "+birthDate+"}";
    }
    
    public void menu(){
        Scanner scanner = new Scanner(System.in);
        boolean run = true;
        
        while (run) { 

        System.out.println("enter your choice: 1.setup account 2.acces to account 3.show all acounts 4.transfer 5.exit");
        int op = scanner.nextInt();
        switch(op){

            case 1:
              if(accounts.size() != accCount){
                System.out.println("enter your ID: ");
                int ID = scanner.nextInt();
            
                System.out.println("enter your balance: ");
                int balance = scanner.nextInt();
    
                accounts.add(new  Account(balance , ID));
                System.out.println("operation Done!");
              }
              else{
                System.out.println("we can't add new account!");
              }
                break;
            case 2:
               
               if(accounts.isEmpty() == false){
                   System.out.println("etner account ID: ");
                   int id = scanner.nextInt();
                   for(Account account : accounts){
                     if(account.getID() ==  id){
                        System.out.println("enter your choice: 1.balance check 2.deposit 3.withdraw 4.exit");
                        int option = scanner.nextInt();
                        if(option == 1){
                            account.check();
                        }
                        else if(option == 2){
                            System.out.println("enter your deposit: ");
                            int amount = scanner.nextInt();
                            account.deposit(amount);
                        }
                        else if(option == 3){
                            System.out.println("enter your withdraw: ");
                            int amount = scanner.nextInt();
                            account.withdraw(amount);
                        }
                        else if(option == 4){
                            System.out.println("EXITING...");
                            
                        }
                        break;

                    }
                    
                       
                    }
                   }
                   
                

            
            else{
                System.out.println("there is no account");
            }
            
            break;
            case 3: 
              if(accounts.isEmpty() == false){
                System.out.println("all acounts: ");
              for (Account account: accounts){
                account.showAll();
              }
              
              }
              else{
                System.out.println("there is no accounts!");
              }
            
               break;
            
            case 4:
               transfer();
               break;
            case 5:
               run = false;
               System.out.println("exiting...");
               break; 
            default: 
               System.out.println("enter a valid choice!");
                    
                
        }
    }
    
    }
}

    


