import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


//super method

public class Bank {
    
    final static int  cusCount = 10;
    static ArrayList<Customer>  clients = new ArrayList<>();
    static ArrayList<Cashier> cashiers = new ArrayList<>();
    

    public void signUp(){
      Scanner scanner = new Scanner(System.in);
      System.out.println("1.customer sign up 2.cashier sign up");
      int op1 = scanner.nextInt();
      if(op1 == 1){
      if (clients.size() != cusCount){
        
       
                System.out.println("Enter your national code:");
                scanner.nextLine();
                String nationalCode = scanner.nextLine(); 
                
                System.out.println("enter your password: ");
                String password = scanner.nextLine();
       
                System.out.println("Enter your name:");
                String name = scanner.nextLine();
                
                System.out.println("Enter your birth date (DDMMYYYY):");
                String birthDate = scanner.nextLine(); 
                
                clients.add(new Customer(nationalCode, name, birthDate , password));
                
                System.out.println("Operation done!"); 
      }
      else{
        System.out.println("we can't add new customer");
      }
    }
    if(op1 == 2){
        
        System.out.println("enter your national code: ");
        scanner.nextLine();
        String nc = scanner.nextLine();

        System.out.println("enter your password: ");
        String pass = scanner.nextLine();

        cashiers.add(new Cashier(pass , nc) );
        System.out.println("operation done!");
        
    }
                
    }

    public static void signIn(){
        Scanner scanner = new Scanner(System.in);
        
        int flag = 0;
        System.out.println("1.customer login  2.cashier login");
        int op2 = scanner.nextInt();
        if(op2 == 1){
        if(clients.isEmpty() == false){
            System.out.println("please enter your national code:");
            scanner.nextLine();
            String NC = scanner.nextLine();
            for (Customer customer : clients){
                if(customer.Nation().equals(NC)){
                   // System.out.println("Welcome back sir!");
                    //customer.menu();
                    customer.logIn();
                    flag += 1;
                    break;
                }
              
            }
            if(flag == 0){
                System.out.println("your input is not correct");
            }
            
        }
        else{
            System.out.println("there is no customer");
        }
    }
    if(op2 == 2){
       if(cashiers.isEmpty() == false){
           System.out.println("enter your national code: ");
           scanner.nextLine();
           String nc = scanner.nextLine();
           int flag1 = 0;
           for(Cashier cashier: cashiers){
               if(cashier.Nation().equals(nc)){
                cashier.logIn();
                flag1 = 1;
                break;
               }
           }
           if(flag1 == 0){
              System.out.println("national code is undefined!");
           }
       } 
    }
    
        
    }

    public void Allcustomers(){
        
        System.out.println("All customers:");
                for (Customer customer : clients) {
                    System.out.println(customer.showInfo());
                }
    }

    public  void search(String NC){
        int flag = 0;
        for(Customer customer : clients){
            if(customer.Nation().equals(NC)){
               System.out.println(customer.showInfo());
                flag++;
                break;
            }
        }
        if(flag == 0){
            System.out.println("customer not found!");
        }
    }

    public void allInfo(String NationCode){
        int flag = 0;
        for(Customer customer : clients){
            if(customer.Nation().equals(NationCode)){
               
               System.out.println(customer.showInfo());
               System.out.println("customer Accounts: ");
               for(Account account : customer.getAccounts()){
                     account.showAll();
               }
               flag++;
               break;
            }
            
        }
       if(flag == 0){
          System.out.println("there is no customer with this national code");
       }
    }

    public void totalMoney(){
        
        int total = 0;

        for (Customer customer : clients) {
            for (Account account : customer.getAccounts()){
                total = total + account.getBalance();
                }
            }
            System.out.println("bank total balance: "+total);
    }

    public void sort(){
        int i , j;
        ArrayList<Integer> sort = new ArrayList<>();
        ArrayList<Integer> finalSort = new ArrayList<>();

        for (Customer customer : clients) {
            sort.add(customer.getAccountBalance());
            }
        

        finalSort = new ArrayList<>(sort);
        Collections.sort(finalSort, Collections.reverseOrder());

        for(i = 0;i < finalSort.size();i++){
            for(j = 0;j < finalSort.size();j++){
                if(finalSort.get(i).equals(sort.get(j))){
                    System.out.println("customer "+j+": total balance = "+sort.get(j));
                    sort.set(j , -1);
                }
            }
        }
        
        
    }


    
    

}
