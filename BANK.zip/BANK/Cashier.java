import java.util.Random;
import java.util.Scanner;


class Cashier extends Person {
   private String password;
   private String nationalCode;
   

   public Cashier(String password , String nationalCode ){
    this.password = password;
    this.nationalCode = nationalCode;
   }


  @Override 
  public void logIn(){
    Scanner scanner = new Scanner(System.in);
    System.out.println("enter your password: ");
    String pass = scanner.nextLine();
    if(this.password.equals(pass)){
        System.out.println("welcome back cash!");
        
    }

  }

  @Override
  public String Nation(){
    return this.nationalCode;
  }

  static int permission(){
    Bank.signIn();
    System.out.println("there is a request for transfer: 1.accept 2.deny");
    Scanner scanner = new Scanner(System.in);
    int per = scanner.nextInt();
    if(per == 1){
       return 1;
    }
    else{
       return 0;
    }

  }


}
        


    

