public class Account{
    private int balance;
    private int ID;
    
    
    
    public Account(int balance , int ID){
        this.balance = balance;
        this.ID = ID;
    }

    public int Info(){
        return ID;
    }

    public void showAll(){
        System.out.println("account{balance: "+balance+"| ID: "+ID+"}");
    }
    
    public void check(){
        System.out.println("your account balance is"+balance);
    }

    public boolean withdraw(int amount){
      if(balance >= amount){
       balance = balance - amount;
       System.out.println("operation done! your new account balance: "+balance);
       return true;
      }
      else{
        System.out.println("not enough money!");
        return false;
      }

    }

    public void deposit(int amount) {
        
            balance = balance + amount;
            System.out.println("operation done! your new accout balance: "+balance);
     }

    public int getBalance(){
        return balance;
    }

    public int getID(){
        return ID;
    }
}